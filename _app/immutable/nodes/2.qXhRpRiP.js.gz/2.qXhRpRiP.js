import{P as m}from"../chunks/2.CwXAaI3_.js";export{m as component};
