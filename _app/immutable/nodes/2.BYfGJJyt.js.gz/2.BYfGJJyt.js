import{P as m}from"../chunks/2.D76NHsRS.js";export{m as component};
