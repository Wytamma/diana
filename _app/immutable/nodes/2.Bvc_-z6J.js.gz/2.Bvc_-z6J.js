import{P as m}from"../chunks/2.BEubKRp1.js";export{m as component};
