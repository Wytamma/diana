import{w as o}from"./index.BuGhtYYs.js";const r=o({locus:void 0});export{r as i};
