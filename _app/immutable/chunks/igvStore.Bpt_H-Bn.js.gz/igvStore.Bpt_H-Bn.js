import{w as o}from"./index.CMPT4qDL.js";const r=o({locus:void 0});export{r as i};
