import{w as o}from"./index.dLrZfUXX.js";const t=o([]);export{t as v};
