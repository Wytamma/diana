import{w as o}from"./index.1X6iZZfA.js";const r=o({locus:void 0});export{r as i};
