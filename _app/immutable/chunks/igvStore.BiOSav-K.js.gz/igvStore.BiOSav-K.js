import{w as o}from"./index.Ccku256h.js";const r=o({locus:void 0});export{r as i};
