import{a as t}from"../chunks/Iq6am496.js";export{t as start};
