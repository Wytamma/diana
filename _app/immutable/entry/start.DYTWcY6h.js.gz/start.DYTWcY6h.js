import{a as t}from"../chunks/entry.B9qgyT1n.js";export{t as start};
