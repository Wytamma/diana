import{a as t}from"../chunks/entry.B9QTFi65.js";export{t as start};
