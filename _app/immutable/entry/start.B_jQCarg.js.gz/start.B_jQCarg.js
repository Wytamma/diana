import{a as t}from"../chunks/mhS3DK2i.js";export{t as start};
