import{a as t}from"../chunks/Ds1pWKGQ.js";export{t as start};
