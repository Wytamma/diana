import{a as t}from"../chunks/yeNeJCoM.js";export{t as start};
