import{a as t}from"../chunks/D73WRUbk.js";export{t as start};
