import{a as t}from"../chunks/entry.CprhXLqF.js";export{t as start};
