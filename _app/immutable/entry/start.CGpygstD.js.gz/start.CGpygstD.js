import{a as t}from"../chunks/CdntlH6m.js";export{t as start};
