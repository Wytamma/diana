import{a as t}from"../chunks/entry.c-j9Mirn.js";export{t as start};
