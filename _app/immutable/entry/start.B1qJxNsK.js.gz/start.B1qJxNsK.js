import{a as t}from"../chunks/DmkSMqe7.js";export{t as start};
