import{a as t}from"../chunks/entry.BXk8cNXC.js";export{t as start};
