import{a as t}from"../chunks/entry.4fVyUDfW.js";export{t as start};
