import{a as t}from"../chunks/entry.DjK1N0XJ.js";export{t as start};
