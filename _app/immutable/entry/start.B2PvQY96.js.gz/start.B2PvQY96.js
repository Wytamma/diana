import{a as t}from"../chunks/entry.SqmMzc3Z.js";export{t as start};
