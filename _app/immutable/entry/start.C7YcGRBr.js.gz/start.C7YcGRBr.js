import{a as t}from"../chunks/entry.DpDpM9gY.js";export{t as start};
