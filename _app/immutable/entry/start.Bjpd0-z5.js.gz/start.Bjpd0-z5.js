import{a as t}from"../chunks/BcEy_IWh.js";export{t as start};
