import{a as t}from"../chunks/entry.BEBu1juy.js";export{t as start};
