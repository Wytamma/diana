import{a as t}from"../chunks/entry.DDkDU8ln.js";export{t as start};
