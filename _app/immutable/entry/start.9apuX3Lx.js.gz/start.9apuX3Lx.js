import{a as t}from"../chunks/entry.DyPW2VWK.js";export{t as start};
