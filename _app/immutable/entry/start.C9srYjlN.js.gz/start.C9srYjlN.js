import{a as t}from"../chunks/entry.DtTCIkos.js";export{t as start};
