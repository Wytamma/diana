import{a as t}from"../chunks/entry.D8OVK0-Z.js";export{t as start};
