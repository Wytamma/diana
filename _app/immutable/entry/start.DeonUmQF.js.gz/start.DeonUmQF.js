import{a as t}from"../chunks/entry.DopQg4Cs.js";export{t as start};
