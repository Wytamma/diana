import{a as t}from"../chunks/entry.NMEZ3Kse.js";export{t as start};
