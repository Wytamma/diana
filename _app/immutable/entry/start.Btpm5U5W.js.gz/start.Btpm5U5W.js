import{a as t}from"../chunks/entry.-2U-BISF.js";export{t as start};
