import{a as t}from"../chunks/entry.jzmy2FHu.js";export{t as start};
