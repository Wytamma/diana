import{a as t}from"../chunks/Dmg1-lcL.js";export{t as start};
