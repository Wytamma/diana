import{a as t}from"../chunks/entry.D_Vv2huQ.js";export{t as start};
