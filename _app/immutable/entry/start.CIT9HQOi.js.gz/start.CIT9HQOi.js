import{a as t}from"../chunks/entry.CzuQ8G6w.js";export{t as start};
