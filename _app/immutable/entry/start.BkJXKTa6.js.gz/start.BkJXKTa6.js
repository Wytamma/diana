import{a as t}from"../chunks/Cm3AQALT.js";export{t as start};
