import{a as t}from"../chunks/entry.DV6nWSOe.js";export{t as start};
