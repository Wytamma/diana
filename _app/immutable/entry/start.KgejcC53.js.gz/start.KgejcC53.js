import{a as t}from"../chunks/entry.DF2-HcU_.js";export{t as start};
