import{a as t}from"../chunks/CUHHdVzL.js";export{t as start};
