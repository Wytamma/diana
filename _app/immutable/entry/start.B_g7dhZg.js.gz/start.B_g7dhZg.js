import{a as t}from"../chunks/CtXL4wv1.js";export{t as start};
