import{a as t}from"../chunks/entry.DHZHaSGZ.js";export{t as start};
