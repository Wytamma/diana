import{a as t}from"../chunks/UdADUmkK.js";export{t as start};
