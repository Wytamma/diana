import{a as t}from"../chunks/entry.C-k7PR0c.js";export{t as start};
