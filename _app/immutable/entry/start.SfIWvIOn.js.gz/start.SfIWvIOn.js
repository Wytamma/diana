import{a as t}from"../chunks/entry.B4A1PJEh.js";export{t as start};
