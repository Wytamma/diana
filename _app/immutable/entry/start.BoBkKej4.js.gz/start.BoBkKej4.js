import{a as t}from"../chunks/entry.BcJGoaaN.js";export{t as start};
