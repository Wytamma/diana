import{a as t}from"../chunks/entry.DjUUNGQa.js";export{t as start};
