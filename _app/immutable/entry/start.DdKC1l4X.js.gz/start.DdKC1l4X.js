import{a as t}from"../chunks/entry.F0AY0ABH.js";export{t as start};
