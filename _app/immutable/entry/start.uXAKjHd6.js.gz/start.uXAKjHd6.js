import{a as t}from"../chunks/entry.slPvI3Qz.js";export{t as start};
