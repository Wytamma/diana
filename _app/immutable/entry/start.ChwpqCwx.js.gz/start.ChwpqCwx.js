import{a as t}from"../chunks/entry.CSjM52y1.js";export{t as start};
