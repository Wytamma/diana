import{a as t}from"../chunks/entry.Du7VUxEw.js";export{t as start};
