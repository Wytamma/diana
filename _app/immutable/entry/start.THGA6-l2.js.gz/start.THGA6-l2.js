import{a as t}from"../chunks/C3qJi18o.js";export{t as start};
