import{a as t}from"../chunks/entry.DvxAfpW2.js";export{t as start};
