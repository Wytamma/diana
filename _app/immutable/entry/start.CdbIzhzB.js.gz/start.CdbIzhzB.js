import{a as t}from"../chunks/entry.DnGP4OkR.js";export{t as start};
