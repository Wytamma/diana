import{a as t}from"../chunks/entry.D7_GvVMx.js";export{t as start};
