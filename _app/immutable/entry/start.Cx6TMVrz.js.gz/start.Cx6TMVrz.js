import{a as t}from"../chunks/entry.Ni2zXmpo.js";export{t as start};
