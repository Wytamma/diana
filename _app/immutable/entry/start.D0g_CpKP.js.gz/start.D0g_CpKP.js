import{a as t}from"../chunks/entry.BgvGjSRw.js";export{t as start};
