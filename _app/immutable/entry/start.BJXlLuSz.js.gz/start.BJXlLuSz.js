import{a as t}from"../chunks/entry.CcE9N9i6.js";export{t as start};
