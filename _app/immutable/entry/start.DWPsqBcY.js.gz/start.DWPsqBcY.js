import{a as t}from"../chunks/entry.BXDl6MTh.js";export{t as start};
