import{a as t}from"../chunks/entry.BcJbq2og.js";export{t as start};
